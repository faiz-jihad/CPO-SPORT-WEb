<?php
include 'koneksi.php';

$id = $_GET['no_lapangan'] ?? null;

if ($id) {
    $id = mysqli_real_escape_string($conn, $id); // untuk keamanan
    $hapus = mysqli_query($conn, "DELETE FROM lapangan WHERE no_lapangan = '$id'");

    if ($hapus) {
        header("Location: lapangan.php?notif=hapus-berhasil");
    } else {
        header("Location: lapangan.php?notif=hapus-gagal");
    }
} else {
    echo "<script>alert('ID tidak ditemukan'); window.location='lapangan.php';</script>";
}
?>
