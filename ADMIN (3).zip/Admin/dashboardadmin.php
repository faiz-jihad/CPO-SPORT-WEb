<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['login'], $_SESSION['idAdmin']) || $_SESSION['login'] !== true) {
    echo "Session tidak valid.";
    exit();
}

// Cek apakah ada aksi delete
if (!isset($_SESSION['deleted_stack'])) {
    $_SESSION['deleted_stack'] = [];
}

$idAdmin = $_SESSION['idAdmin'] ?? null;

if ($idAdmin) {
    $stmt = $conn->prepare("SELECT namaAdmin, jabatan FROM admincpo WHERE idAdmin = ?");
    $stmt->bind_param("i", $idAdmin);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $namaAdmin = $row['namaAdmin'];
        $jabatan = $row['jabatan'];
    } else {
        exit();
    }
    $stmt->close();
} else {
    exit();
}
?>

<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/webrtc-adapter/3.3.3/adapter.min.js"></script>
    <script type="text/javascript" src="https://unpkg.com/html5-qrcode/minified/html5-qrcode.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>


    <title>CPO SPORT ADMIN</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                <div class="sidebar-brand-icon rotate-n-0">
                    <i class="bi bi-briefcase-fill"></i>
                </div>
                <div class="sidebar-brand-text mx-3">CPO | ADMIN <sup>2</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Fitur
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="bi bi-people-fill"></i>
                    <span>Data Pelanggan</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="pelanggan.php">Akun Pelanggan</a>
                        <a class="collapse-item" href="transaksipelanggan.php">Transaksi Pelanggan</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->

            <li class="nav-item">
                <a class="nav-link" href="lapangan.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Lapangan</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="komentar.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Komentar</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="daftaradmin.php">
                    <i class="bi bi-person-badge-fill"></i>
                    <span>Kelola Admin</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseketentuan"
                    aria-expanded="true" aria-controls="collapseketentuan">
                    <i class="bi bi-body-text"></i>
                    <span>Data Ketentuan</span>
                </a>
                <div id="collapseketentuan" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="EditTentangKita.php">Tentang Kita</a>
                        <a class="collapse-item" href="pelayanan.php">Pelayanan</a>
                        <a class="collapse-item" href="ketentuanberlaku.php">Ketentuan Berlaku</a>
                    </div>
                </div>
            </li>


            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <h3> Dashboard</h3>
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">



                        <div class="topbar-divider d-none d-sm-block"></div>


                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <div class="text-right mr-2">
                                    <div class="text-gray-900 big"><?php echo $namaAdmin; ?></div>
                                    <div class="text-gray-600 small"><?php echo $jabatan; ?></div>
                                </div>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>


                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logoutadmin.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Fungsi Kalkulasi -->
                <?php
                // Jumlah pelanggan
                $pelanggan = $conn->query("SELECT COUNT(*) as total FROM pelanggan");
                $jumlahPelanggan = $pelanggan->fetch_assoc()['total'];

                // Jumlah transaksi
                $transaksi = $conn->query("SELECT COUNT(*) as total FROM booking");
                $jumlahTransaksi = $transaksi->fetch_assoc()['total'];

                // Total pemasukan
                $pemasukan = $conn->query("SELECT SUM(total_harga) as total FROM booking");
                $totalPemasukan = 0; // Inisialisasi total pemasukan
                $totalPemasukan = $pemasukan->fetch_assoc()['total'];
                ?>

                <?php
                // Set zona waktu lokal
                date_default_timezone_set('Asia/Jakarta');

                // Tanggal hari ini
                $tanggalHariIni = date('Y-m-d');

                // Ambil transaksi hari ini
                $queryHariIni = "SELECT booking.no_transaksi, pelanggan.username, lapangan.no_lapangan, booking.tanggal_transaksi, booking.total_harga, booking.status, booking.jam_mulai
FROM booking
JOIN pelanggan ON booking.id_pelanggan = pelanggan.id_pelanggan
JOIN lapangan ON booking.no_lapangan = lapangan.no_lapangan
WHERE DATE(booking.tanggal_transaksi) = '$tanggalHariIni'
ORDER BY booking.tanggal_transaksi DESC";

                $resultHariIni = mysqli_query($conn, $queryHariIni);
                ?>





                <!-- Update transaksi -->
                <?php
                if (isset($_GET['update_status'], $_GET['id'])) {
                    $status = $_GET['update_status'];
                    $id = $_GET['id'];

                    // Validasi enum manual untuk keamanan
                    $allowed = ['pending', 'berhasil', 'dibatalkan'];
                    if (in_array($status, $allowed)) {
                        $stmt = $conn->prepare("UPDATE booking SET status = ? WHERE no_transaksi = ?");
                        $stmt->bind_param("ss", $status, $id);
                        $stmt->execute();
                    }
                } ?>



                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Heading -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h1 class="h3 text-gray-800">Selamat Datang, Admin!</h1>
                            <h5 class="text-muted">Aplikasi CPO SPORT | 2025</h5>
                        </div>
                    </div>

                    <!-- Informasi Card -->
                    <div class="row g-4">

                        <!-- Jumlah Pelanggan -->
                        <div class="col-xl-4 col-md-6">
                            <div class="card shadow border-start-primary h-100">
                                <div class="card-body d-flex align-items-center justify-content-between">
                                    <div>
                                        <div class="text-primary fw-bold text-uppercase mb-1">Jumlah Pelanggan</div>
                                        <div class="h5 fw-bold mb-0 text-gray-800"><?= $jumlahPelanggan ?></div>
                                    </div>
                                    <i class="bi bi-person-fill fs-1 text-primary"></i>
                                </div>
                            </div>
                        </div>

                        <!-- Jumlah Transaksi -->
                        <div class="col-xl-4 col-md-6">
                            <div class="card shadow border-start-success h-100">
                                <div class="card-body d-flex align-items-center justify-content-between">
                                    <div>
                                        <div class="text-success fw-bold text-uppercase mb-1">Total Transaksi</div>
                                        <div class="h5 fw-bold mb-0 text-gray-800"><?= $jumlahTransaksi ?></div>
                                    </div>
                                    <i class="bi bi-card-checklist fs-1 text-success"></i>
                                </div>
                            </div>
                        </div>

                        <!-- Total Pemasukan -->
                        <div class="col-xl-4 col-md-6">
                            <div class="card shadow border-start-warning h-100">
                                <div class="card-body d-flex align-items-center justify-content-between">
                                    <div>
                                        <div class="text-warning fw-bold text-uppercase mb-1">Total Pemasukan</div>
                                        <div class="h5 fw-bold mb-0 text-gray-800">Rp <?= number_format($totalPemasukan, 0, ',', '.') ?></div>
                                    </div>
                                    <i class="bi bi-currency-dollar fs-1 text-warning"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Grafik Transaksi -->
                    <div class="card shadow mt-5">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6 class="m-0 fw-bold text-primary">Grafik Transaksi</h6>
                            <select id="filter" class="form-select w-auto">
                                <option value="harian">Harian</option>
                                <option value="mingguan">Mingguan</option>
                                <option value="bulanan" selected>Bulanan</option>
                                <option value="tahunan">Tahunan</option>
                            </select>
                        </div>
                        <div class="card-body" style="height: 400px;">
                            <canvas id="transaksiChart"></canvas>
                        </div>
                    </div><!-- Tabel Transaksi Hari Ini -->
                    <div class="card shadow mt-5">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6 class="m-0 fw-bold text-primary">Transaksi Hari Ini (<?= date('d M Y') ?>)</h6>
                            <div>
                                <a href="export_laporan_tanggal.php" class="btn btn-success btn-sm">
                                    <i class="fas fa-file-excel"></i> Excel
                                </a>
                            </div>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead class="table-primary">
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Booking</th>
                                        <th>Nama Pelanggan</th>
                                        <th>Lapangan</th>
                                        <th>Tanggal</th>
                                        <th>Total Harga</th>
                                        <th>Jam Mulai</th>
                                        <th>Jam Selesai</th>
                                        <th>Aksi</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (mysqli_num_rows($resultHariIni) > 0): ?>
                                        <?php $i = 1;
                                        while ($row = mysqli_fetch_assoc($resultHariIni)):
                                        ?>
                                            <tr>
                                                <td><?= $i++ ?></td>
                                                <td><?= $row['no_transaksi'] ?></td>
                                                <td><?= $row['username'] ?></td>
                                                <td><?= $row['no_lapangan'] ?></td>
                                                <td><?= date('d-m-Y ', strtotime($row['tanggal_transaksi'])) ?></td>
                                                <td>Rp <?= number_format($row['total_harga'], 0, ',', '.') ?></td>
                                                <td><?= date('H:i', strtotime($row['jam_mulai'])) ?></td>
                                                <td><?= date('H:i', strtotime($row['jam_mulai'] . ' +2 hours')) ?></td>
                                                <td>
                                                    <a href="?update_status=berhasil&id=<?= $row['no_transaksi'] ?>" class="btn btn-success btn-sm">Sukses</a>
                                                    <a href="?delete=<?= $row['no_transaksi'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin membatalkan transaksi ini?')">Batalkan</a>
                                                </td>
                                                <td>
                                                    <?php
                                                    $status = strtolower($row['status']);
                                                    $badge = 'secondary';
                                                    if ($status == 'berhasil') $badge = 'success';
                                                    elseif ($status == 'pending') $badge = 'warning';
                                                    elseif ($status == 'dibatalkan') $badge = 'danger';
                                                    ?>
                                                    <span class="badge bg-<?= $badge ?>"><?= ucfirst($status) ?></span>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="10" class="text-center text-muted">Tidak ada transaksi hari ini.</td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php
                                    if (isset($_GET['delete'])) {
                                        $no_transaksi = $_GET['delete'];

                                        // Ambil data sebelum hapus
                                        $stmt = $conn->prepare("SELECT * FROM booking WHERE no_transaksi = ?");
                                        $stmt->bind_param("s", $no_transaksi);
                                        $stmt->execute();
                                        $result = $stmt->get_result();

                                        if ($row = $result->fetch_assoc()) {
                                            $_SESSION['deleted_stack'][] = $row;

                                            // Hapus data
                                            $stmt = $conn->prepare("DELETE FROM booking WHERE no_transaksi = ?");
                                            $stmt->bind_param("s", $no_transaksi);
                                            $stmt->execute();
                                        }
                                    }
                                    ?>
                                    <!-- hapus -->
                                    <?php if (!empty($_SESSION['deleted_stack'])): ?>
                                        <form method="post">
                                            <button type="submit" name="undo_delete" class="btn btn-primary mb-2">Pulihkan Transaksi</button>
                                        </form>
                                    <?php endif; ?>
                                    <?php
                                    if (isset($_POST['undo_delete']) && !empty($_SESSION['deleted_stack'])) {
                                        $lastDeleted = array_pop($_SESSION['deleted_stack']);

                                        // Kembalikan ke database
                                        $stmt = $conn->prepare("INSERT INTO booking (no_transaksi, id_pelanggan, username, no_lapangan, tanggal_transaksi, durasi, jam_mulai, jam_selesai,nomor_telepon)
                                        VALUES (?, ?, ?, ?, ?, ?, ?,?,?)");
                                        $stmt->bind_param(
                                            "ssssssss",
                                            $lastDeleted['no_transaksi'],
                                            $lastDeleted['id_pelanggan'],
                                            $nomor_telepon['nomor_telepon'],
                                            $lastDeleted['username'],
                                            $lastDeleted['no_lapangan'],
                                            $lastDeleted['tanggal_transaksi'],
                                            $lastDeleted['durasi'],
                                            $lastDeleted['jam_mulai'],
                                            $lastDeleted['jam_selesai']
                                        );
                                        $stmt->execute();
                                    }
                                    ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                    <div class="container mt-5">
                        <div class="card shadow">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h6 class="m-0 font-weight-bold text-primary">QR Code Scanner</h6>
                            </div>
                            <div class="card-body">
                                <form action="cek_code.php" method="POST">
                                    <div class="form-group">
                                        <label for="scanner">Scan QR Code:</label>
                                        <input type="text" name="scanner" id="scanner" class="form-control" placeholder="Tempel hasil scan di sini" autofocus required>
                                    </div>
                                    <button type="submit" name="submit" class="btn btn-primary btn-block">Submit</button>
                                </form>

                                <!-- Camera Scanner Frame -->
                                <div id="reader" class="scanner-frame"></div>

                                <div class="mt-4">
                                    <h5>Hasil Scan</h5>
                                    <ul id="scan-result" class="list-group">
                                        <li class="list-group-item text-muted">Belum ada hasil</li>
                                    </ul>
                                </div>
                                <button onclick="startScanner()" class="btn btn-secondary mt-3">Coba Lagi</button>

                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <!-- /.container-fluid -->



            <div class="container-fluid">
                <div class="card-body" style="width: 100%; height: 400px;">
                </div>
            </div>
            /

            <!-- Custom styles for the QR Scanner frame -->
            <style>
                #reader {
                    max-width: 100%;
                    width: 100%;
                    height: auto;
                    aspect-ratio: 4 / 3;
                    /* Membuat area kamera tetap proporsional */
                    border: 2px dashed #007bff;
                    border-radius: 10px;
                    margin-top: 20px;
                    background-color: #e9ecef;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    overflow: hidden;
                    position: relative;
                }

                @media (min-width: 768px) {
                    #reader {
                        width: 600px;
                        height: 450px;
                        margin-left: auto;
                        margin-right: auto;
                    }
                }

                .scanner-frame {
                    text-align: center;
                }
            </style>

            <!-- End of Main Content -->
            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; CPO SPORT ADMIN </span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

            <!-- End of Content Wrapper -->
        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">klik Tombol Log Out untuk Keluar</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="logoutadmin.php">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart -->
    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Area Chart Initialization -->
    <script>
        const ctx = document.getElementById('transaksiChart').getContext('2d');
        let chart;

        function loadChartData(filter) {
            fetch(`get_chart_data.php?filter=${filter}`)
                .then(response => response.json())
                .then(data => {
                    if (chart) chart.destroy(); // Hapus chart lama jika ada

                    chart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: data.labels,
                            datasets: [{
                                label: 'Jumlah Transaksi',
                                data: data.values,
                                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 2,
                                fill: true,
                                tension: 0.3
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                });
        }

        document.getElementById('filter').addEventListener('change', function() {
            loadChartData(this.value);
        });

        // Load default chart saat halaman pertama kali dibuka
        window.addEventListener('load', () => {
            loadChartData('bulanan');
        });
    </script>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Chart Library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    <!-- QR Code Scanner -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.6.14/vue.min.js"></script>

    <script>
        let html5QrCode;

        function onScanSuccess(decodedText) {
            console.log("Scan result:", decodedText);
            document.getElementById('scanner').value = decodedText;

            html5QrCode.stop().then(() => {
                console.log("Scanner stopped.");
            }).catch(err => {
                console.error("Gagal menghentikan scanner:", err);
            });

            // Kirim ke cek_kode.php

            fetch("cek_kode.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: `kode=${encodeURIComponent(decodedText)}`
                })
                .then(response => response.json())
                .then(result => {
                    const resultList = document.getElementById('scan-result');
                    resultList.innerHTML = '';

                    if (result.status === 'success') {
                        const data = result.data;
                        const item = document.createElement('li');
                        item.classList.add('list-group-item', 'list-group-item-success');
                        item.innerHTML = `
                        <strong>Kode:</strong> ${data.kode_booking}<br>
                        <strong>Nama:</strong> ${data.nama_pemesan}<br>
                        <strong>Lapangan:</strong> ${data.nama_lapangan}<br>
                        <strong>Tanggal:</strong> ${data.tanggal}<br>
                        <strong>Total:</strong> Rp ${parseInt(data.total_harga).toLocaleString()}<br>
                        <strong>Status:</strong> <span class="badge bg-success">Berhasil</span>
                    `;
                        resultList.appendChild(item);
                    } else {
                        const item = document.createElement('li');
                        item.classList.add('list-group-item', 'text-danger');
                        item.textContent = result.message;
                        resultList.appendChild(item);
                    }
                })
                .catch(err => {
                    console.error("Fetch error:", err);
                });
        }

        function onScanError(errorMessage) {
            console.warn("QR Scan error:", errorMessage);
        }

        function startScanner() {
            html5QrCode = new Html5Qrcode("reader");

            Html5Qrcode.getCameras().then(devices => {
                if (devices && devices.length > 0) {
                    const cameraId = devices[0].id;
                    html5QrCode.start(cameraId, {
                            fps: 10,
                            qrbox: 250
                        }, onScanSuccess, onScanError)
                        .catch(err => {
                            console.error("Gagal memulai scanner:", err);
                            alert("Gagal memulai scanner. Izinkan akses kamera.");
                        });
                } else {
                    alert("Tidak ada kamera yang ditemukan.");
                }
            }).catch(err => {
                console.error("Tidak bisa mengakses kamera:", err);
                alert("Tidak bisa mengakses kamera: " + err);
            });
        }

        window.addEventListener('load', () => {
            startScanner();
        });
    </script>

    </script>
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script src="https://unpkg.com/html5-qrcode/minified/html5-qrcode.min.js"></script>

    </script>
</body>

</html>