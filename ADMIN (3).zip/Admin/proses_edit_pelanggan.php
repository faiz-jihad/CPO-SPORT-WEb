
<?php
include 'koneksi.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    if (!empty($password)) {
        // Jika password diisi, update semua
        $update = mysqli_query($conn, "UPDATE pelanggan SET 
            Nama='$nama',
            Username='$username',
            Phone='$phone',
            Password='$password'
            WHERE id_pelanggan='$id'");
    } else {
        // Jika password tidak diubah
        $update = mysqli_query($conn, "UPDATE pelanggan SET 
            Nama='$nama',
            Username='$username',
            Phone='$phone'
            WHERE id_pelanggan='$id'");
    }

    if ($update) {
        header("Location: pelanggan.php?notif=edit-berhasil");
    } else {
        header("Location: pelanggan.php?notif=edit-gagal");
    }
}
?>
