<?php
include 'koneksi.php';

$filter = $_GET['filter'] ?? 'bulanan';
$data = [
    'labels' => [],
    'values' => []
];

switch ($filter) {
    case 'harian':
        $query = "SELECT DATE(tanggal_transaksi) AS label, COUNT(*) AS total 
                  FROM booking 
                  GROUP BY DATE(tanggal_transaksi) 
                  ORDER BY tanggal_transaksi ASC";
        break;

    case 'mingguan':
        $query = "SELECT YEAR(tanggal_transaksi) AS tahun, WEEK(tanggal_transaksi) AS minggu, COUNT(*) AS total 
                  FROM booking 
                  GROUP BY tahun, minggu 
                  ORDER BY tahun, minggu ASC";
        break;

    case 'tahunan':
        $query = "SELECT YEAR(tanggal_transaksi) AS tahun, COUNT(*) AS total 
                  FROM booking 
                  GROUP BY tahun 
                  ORDER BY tahun ASC";
        break;

    case 'bulanan':
    default:
        $query = "SELECT MONTH(tanggal_transaksi) AS bulan, YEAR(tanggal_transaksi) AS tahun, COUNT(*) AS total 
                  FROM booking 
                  GROUP BY tahun, bulan 
                  ORDER BY tahun, bulan ASC";
        break;
}

$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {
    if ($filter === 'harian') {
        $data['labels'][] = date('d M Y', strtotime($row['label']));
    } elseif ($filter === 'mingguan') {
        $data['labels'][] = 'Minggu ' . $row['minggu'] . ' - ' . $row['tahun'];
    } elseif ($filter === 'bulanan') {
        $bulanNama = DateTime::createFromFormat('!m', $row['bulan'])->format('F');
        $data['labels'][] = $bulanNama . ' ' . $row['tahun'];
    }
    $data['values'][] = (int) $row['total'];
}

header('Content-Type: application/json');
echo json_encode($data);
