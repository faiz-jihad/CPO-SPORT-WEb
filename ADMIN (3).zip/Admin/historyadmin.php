<?php
include 'koneksi.php';

// Ambil semua riwayat perubahan
$query = "SELECT * FROM admin_history ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Admin</title>
</head>
<body>
    <h3>Riwayat Perubahan Admin</h3>
    <table border="1">
        <thead>
            <tr>
                <th>ID Admin</th>
                <th>Nama Admin</th>
                <th>Jabatan</th>
                <th>No Telepon</th>
                <th>Aksi</th>
                <th>Waktu</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($history = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= htmlspecialchars($history['idAdmin']) ?></td>
                    <td><?= htmlspecialchars($history['namaAdmin']) ?></td>
                    <td><?= htmlspecialchars($history['jabatan']) ?></td>
                    <td><?= htmlspecialchars($history['noTelepon']) ?></td>
                    <td><?= htmlspecialchars($history['action_type']) ?></td>
                    <td><?= htmlspecialchars($history['created_at']) ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
