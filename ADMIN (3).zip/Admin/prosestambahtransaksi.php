<?php
include 'koneksi.php';
session_start();

// Cek apakah admin sudah login
// if (!isset($_SESSION['idAdmin'])) {
//     echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
//     echo "<script>
//             document.addEventListener('DOMContentLoaded', function() {
//                 swal('Warning!', 'Harap login sebagai admin!', 'warning')
//                 .then(() => { window.location.href = 'halamanlogin.php'; });
//             });
//          </script>";
//     exit();
// }

date_default_timezone_set('Asia/Jakarta'); // Set timezone

// Ambil data dari form
// $id_pelanggan       = $_POST['id_pelanggan'] ?? '';
$nama_pelanggan     = $_POST['nama_pelanggan'] ?? '';
$nomor_telepon      = $_POST['nomor_telepon'] ?? '';
$no_lapangan        = $_POST['no_lapangan'] ?? '';
$tanggal_transaksi  = $_POST['tanggal_transaksi'] ?? '';
$jam_mulai          = $_POST['jam_mulai'] ?? '';
$durasi             = isset($_POST['durasi']) ? intval($_POST['durasi']) : 1;
$$status = $_POST['status'] ?? 'pending';

// $id_admin           = $_SESSION['admin_id'];
$no_transaksi       = uniqid('TRX_');
$total_harga        = 0;

// Validasi input
if (empty($nama_pelanggan) || empty($nomor_telepon) || empty($no_lapangan) || empty($tanggal_transaksi) || empty($jam_mulai) || $durasi <= 0) {
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                swal('Error!', 'Semua kolom harus diisi!', 'error')
                .then(() => { window.location.href = 'tambahtransaksi.php'; });
            });
         </script>";
    exit();
}

if (strtotime($tanggal_transaksi) < strtotime(date("Y-m-d"))) {
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                swal('Error!', 'Tanggal transaksi tidak boleh di masa lalu!', 'error')
                .then(() => { window.location.href = 'tambahtransaksi.php'; });
            });
         </script>";
    exit();
}

// Hitung jam selesai
$jam_selesai = date("H:i:s", strtotime($jam_mulai) + ($durasi * 3600));

// Hitung harga per jam
$jam_int = intval(date("H", strtotime($jam_mulai)));
$harga_per_jam = ($jam_int < 18) ? 35000 : 40000;

$total_harga = $durasi * $harga_per_jam;

// Cek bentrok jadwal
$query = "SELECT COUNT(*) FROM booking WHERE no_lapangan = ? AND tanggal_transaksi = ?
            AND ((jam_mulai < ? AND jam_selesai > ?))";
$cek = $conn->prepare($query);
$cek->bind_param("ssss", $no_lapangan, $tanggal_transaksi,  $jam_mulai, $jam_selesai);
$cek->execute();
$cek->bind_result($jumlah);
$cek->fetch();
$cek->close();

if ($jumlah > 0) {
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                swal('Error!', 'Jadwal bentrok dengan transaksi lain!', 'error')
                .then(() => { window.location.href = 'tambahtransaksi.php'; });
            });
         </script>";
    exit();
}

// Simpan ke DB
$stmt = $conn->prepare("INSERT INTO booking (no_transaksi, username, no_lapangan, nomor_telepon, tanggal_transaksi, jam_mulai, durasi, jam_selesai, total_harga, status) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("ssssssssis", $no_transaksi, $nama_pelanggan, $no_lapangan, $nomor_telepon, $tanggal_transaksi, $jam_mulai, $durasi, $jam_selesai, $total_harga, $status);


if ($stmt->execute()) {
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                swal('Sukses!', 'Transaksi berhasil ditambahkan.', 'success')
                .then(() => { window.location.href = 'transaksipelanggan.php'; });
            });
         </script>";
} else {
    $err = htmlspecialchars($stmt->error);
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                swal('Error!', 'Gagal menambahkan transaksi: $err', 'error')
                .then(() => { window.location.href = 'tambahtransaksi.php'; });
            });
         </script>";
}

$stmt->close();
$conn->close();
?>
