<?php
session_start();
require_once 'koneksi.php';


if (isset($_POST['login'])) {
    $noTelepon = trim($_POST['noTelepon']);
    $password = trim($_POST['Password']);

    if (empty($noTelepon) || empty($password)) {
        echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                swal({
                    title: 'Gagal!',
                    text: 'Nomor atau Password Wajib di isi',
                    icon: 'error',
                    button: 'OK'
                }).then((value) => {
                    window.location.href = 'loginadmin.php';
                });
            });
            </script>";
        exit();
    }

    // Menggunakan Prepared Statement agar lebih aman
    $query = "SELECT idAdmin, namaAdmin, noTelepon, Password FROM admincpo WHERE noTelepon = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $noTelepon);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Bandingkan password secara langsung (karena tanpa hash)
        if ($password === $user['Password']) {
            $_SESSION['login'] = true;
            $_SESSION['idAdmin'] = $user['idAdmin'];
            $_SESSION['noTelepon'] = $user['noTelepon'];
            $_SESSION['namaAdmin'] = $user['namaAdmin'];

            header("Location: dashboardadmin.php");
            exit();
        } else {
            echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                swal({
                    title: 'Password Salah!',
                    text: 'Password yang anda masukan salah',
                    icon: 'error',
                    button: 'OK'
                }).then((value) => {
                    window.location.href = 'loginadmin.php';
                });
            });
            </script>";
        }
    } else {
        echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                swal({
                    title: 'No HP Salah!',
                    text: 'No HP tidak terdaftar!',
                    icon: 'error',
                    button: 'OK'
                }).then((value) => {
                    window.location.href = 'loginadmin.php';
                });
            });
            </script>";
    }

    $stmt->close();
    $conn->close();
}
?>
