<?php
include 'koneksi.php';
session_start();

// Authentication Check - Uncomment if needed
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: loginadmin.php");
    exit();
}

// Ambil idAdmin dari session (pastikan idAdmin disimpan saat login)
$idAdmin = $_SESSION['idAdmin'] ?? null;

if ($idAdmin) {
    // Prepared Statement for fetching admin details
    $query = "SELECT namaAdmin, jabatan FROM admincpo WHERE idAdmin = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $idAdmin);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $namaAdmin = $row['namaAdmin'];
        $jabatan = $row['jabatan'];
    } else {
        exit("Admin not found");
    }
} else {
    exit("Invalid session");
}

// Fetching all admins for display in table
$adminQuery = "SELECT * FROM admincpo";
$adminResult = mysqli_query($conn, $adminQuery);

// Process Add Admin
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['tambah_admin'])) {
    // Get the user input
    $namaBaru = $_POST['namaAdmin'];
    $jabatanBaru = $_POST['jabatan'];
    $noTelepon = $_POST['noTelepon'];
    $Password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encrypt the password

    // Prepared Statement to Insert Admin
    $stmt = $conn->prepare("INSERT INTO admincpo (namaAdmin, jabatan, Password, noTelepon) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $namaBaru, $jabatanBaru, $Password, $noTelepon);

    if ($stmt->execute()) {
        $admin_id = $stmt->insert_id;
        // Log the action in the admin_history table
        $historyQuery = "INSERT INTO admin_history (idAdmin, namaAdmin, jabatan, noTelepon, action_type) 
                         VALUES (?, ?, ?, ?, 'add')";
        $stmt2 = $conn->prepare($historyQuery);
        $stmt2->bind_param("isss", $admin_id, $namaBaru, $jabatanBaru, $noTelepon);
        $stmt2->execute();

        echo '<div class="alert alert-success">Admin berhasil ditambahkan.</div>';
        echo '<meta http-equiv="refresh" content="1">';
    } else {
        echo '<div class="alert alert-danger">Gagal menambahkan admin: ' . $stmt->error . '</div>';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_admin'])) {
    $editId = $_POST['idAdmin'];
    $namaAdmin = $_POST['namaAdmin'];
    $jabatan = $_POST['jabatan'];
    $noTelepon = $_POST['noTelepon'];

    $query = "SELECT * FROM admincpo WHERE idAdmin = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $editId);
    $stmt->execute();
    $result = $stmt->get_result();
    $oldData = $result->fetch_assoc();

    $historyQuery = "INSERT INTO admin_history (idAdmin, namaAdmin, jabatan, noTelepon, action_type) 
                     VALUES (?, ?, ?, ?, 'edit')";
    $stmt2 = $conn->prepare($historyQuery);
    $stmt2->bind_param("isss", $editId, $oldData['namaAdmin'], $oldData['jabatan'], $oldData['noTelepon']);
    $stmt2->execute();

    $updateQuery = "UPDATE admincpo SET namaAdmin = ?, jabatan = ?, noTelepon = ? WHERE idAdmin = ?";
    $stmt3 = $conn->prepare($updateQuery);
    $stmt3->bind_param("sssi", $namaAdmin, $jabatan, $noTelepon, $editId);

    if ($stmt3->execute()) {
        header("Location: daftaradmin.php");
        exit();
    } else {
        echo "Error: " . $stmt3->error;
    }
}


// Process Delete Admin (if requested)
if (isset($_GET['id'])) {
    $idToDelete = $_GET['id'];

    // Fetch admin data before deletion for logging
    $query = "SELECT * FROM admincpo WHERE idAdmin = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $idToDelete);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    // Log the delete action
    $historyQuery = "INSERT INTO admin_history (idAdmin, namaAdmin, jabatan, noTelepon, action_type) 
                     VALUES (?, ?, ?, ?, 'delete')";
    $stmt2 = $conn->prepare($historyQuery);
    $stmt2->bind_param("isss", $idToDelete, $admin['namaAdmin'], $admin['jabatan'], $admin['noTelepon']);
    $stmt2->execute();

    // Delete the admin
    $deleteQuery = "DELETE FROM admincpo WHERE idAdmin = ?";
    $stmt3 = $conn->prepare($deleteQuery);
    $stmt3->bind_param("i", $idToDelete);

    if ($stmt3->execute()) {
        header("Location: daftaradmin.php");
        exit();
    } else {
        echo "Error: " . $stmt3->error;
    }
}
?>

<!-- HTML -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>CPO SPORT ADMIN</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">


</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboardadmin.php">
                <div class="sidebar-brand-icon rotate-n-0">
                    <i class="bi bi-briefcase-fill"></i>
                </div>
                <div class="sidebar-brand-text mx-3">CPO | ADMIN <sup>2</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="dashboardadmin.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Fitur
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="bi bi-people-fill"></i>
                    <span>Data Pelanggan</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="pelanggan.php">Akun Pelanggan</a>
                        <a class="collapse-item" href="transaksipelanggan.php">Transaksi Pelanggan</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->

            <li class="nav-item">
                <a class="nav-link" href="lapangan.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Lapangan</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="komentar.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Komentar</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="daftaradmin.php">
                    <i class="bi bi-person-badge-fill"></i>
                    <span>Kelola Admin</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseketentuan"
                    aria-expanded="true" aria-controls="collapseketentuan">
                    <i class="bi bi-body-text"></i>
                    <span>Data Ketentuan</span>
                </a>
                <div id="collapseketentuan" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="EditTentangKita.php">Tentang Kita</a>
                        <a class="collapse-item" href="pelayanan.php">Pelayanan</a>
                        <a class="collapse-item" href="ketentuanberlaku.php">Ketentuan Berlaku</a>
                    </div>
                </div>
            </li>


            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <h3> Kelola Admin</h3>
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">



                        <div class="topbar-divider d-none d-sm-block"></div>


                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <div class="text-right mr-2">
                                    <div class="text-gray-900 big"><?php echo $namaAdmin; ?></div>
                                    <div class="text-gray-600 small"><?php echo $jabatan; ?></div>
                                </div>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>


                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logoutadmin.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->
                <?php
                // Ambil data semua admin dari database
                $adminQuery = "SELECT * FROM admincpo";
                $adminResult = mysqli_query($conn, $adminQuery);
                ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Tabel Admin -->
                    <div class="container-fluid">
                        <h4 class="mb-3">Daftar Akun Admin</h4>
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">Tabel Admin</div>
                            <div class="card-body">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama</th>
                                            <th>Jabatan</th>
                                            <th>No Hp</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($admin = mysqli_fetch_assoc($adminResult)): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($admin['idAdmin']) ?></td>
                                                <td><?= htmlspecialchars($admin['namaAdmin']) ?></td>
                                                <td><?= htmlspecialchars($admin['jabatan']) ?></td>
                                                <td><?= htmlspecialchars($admin['noTelepon']) ?></td>
                                                <td>
                                                    <!-- Edit Button -->
                                                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $admin['idAdmin'] ?>">Edit</button>

                                                    <!-- Delete Button -->
                                                    <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?= $admin['idAdmin'] ?>">Hapus</button>

                                                </td>
                                            </tr>

                                            <!-- Edit Modal -->
                                            <div class="modal fade" id="editModal<?= $admin['idAdmin'] ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $admin['idAdmin'] ?>" aria-hidden="true">

                                                <div class="modal-dialog">
                                                    <form method="post">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="editModalLabel<?= $admin['idAdmin'] ?>">Edit Admin</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <input type="hidden" name="edit_admin" value="1">
                                                                <input type="hidden" name="idAdmin" value="<?= $admin['idAdmin'] ?>">
                                                                <div class="mb-3">
                                                                    <label>Nama</label>
                                                                    <input type="text" name="namaAdmin" class="form-control" value="<?= htmlspecialchars($admin['namaAdmin']) ?>" required>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label>Jabatan</label>
                                                                    <select name="jabatan" class="form-control" required>
                                                                        <option <?= $admin['jabatan'] == 'Admin' ? 'selected' : '' ?>>Admin</option>
                                                                        <option <?= $admin['jabatan'] == 'Pegawai' ? 'selected' : '' ?>>Pegawai</option>
                                                                        <option <?= $admin['jabatan'] == 'Staf Keuangan' ? 'selected' : '' ?>>Staf Keuangan</option>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label>No Telepon</label>
                                                                    <input type="text" name="noTelepon" class="form-control" value="<?= htmlspecialchars($admin['noTelepon']) ?>" required>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <!-- Delete Modal -->
                                            <div class="modal fade" id="deleteModal<?= $admin['idAdmin'] ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?= $admin['idAdmin'] ?>" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="deleteModalLabel<?= $admin['idAdmin'] ?>">Konfirmasi Hapus</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Apakah Anda yakin ingin menghapus admin <strong><?= htmlspecialchars($admin['namaAdmin']) ?></strong>?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a href="?id=<?= $admin['idAdmin'] ?>" class="btn btn-danger">Ya, Hapus</a>
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                        <!-- Form Tambah Admin -->
                        <div class="card">
                            <div class="card-header bg-success text-white">Daftarkan Admin Baru</div>
                            <div class="card-body">
                                <form method="post">
                                    <input type="hidden" name="tambah_admin" value="1">
                                    <div class="mb-3">
                                        <label for="namaAdmin" class="form-label">Nama Admin</label>
                                        <input type="text" name="namaAdmin" id="namaAdmin" class="form-control" required>
                                    </div>
                                    <select name="jabatan" id="jabatan" class="form-control" required>
                                        <option value="" disabled selected>Pilih Jabatan</option>
                                        <option value="Admin">Admin </option>
                                        <option value="Pegawai">Pegawai</option>
                                        <option value="Staf Keuangan">Staf Keuangan</option>
                                    </select>
                                    <div class="mb-3">
                                        <label for="noTelepon" class="form-label">No Telepon Admin</label>
                                        <input type="text" name="noTelepon" id="noTelepon" class="form-control" required>
                                        <div class="mb-3">
                                            <label for="password" class="form-label">Password Admin</label>
                                            <input type="password" name="password" id="password" class="form-control" required>
                                        </div>
                                        <button type="submit" class="btn btn-success">Tambah Admin</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Heading -->



                    <!-- End of Main Content -->
                    <!-- Footer -->
                    <footer class="sticky-footer bg-white">
                        <div class="container my-auto">
                            <div class="copyright text-center my-auto">
                                <span>Copyright &copy; CPO SPORT ADMIN </span>
                            </div>
                        </div>
                    </footer>
                    <!-- End of Footer -->

                    <!-- End of Content Wrapper -->
                </div>
                <!-- End of Page Wrapper -->

                <!-- Scroll to Top Button-->
                <a class="scroll-to-top rounded" href="#page-top">
                    <i class="fas fa-angle-up"></i>
                </a>

                <!-- Logout Modal-->
                <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">klik Tombol Log Out untuk Keluar</div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                <a class="btn btn-primary" href="logoutadmin.php">Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <!-- Bootstrap core JavaScript-->
            <script src="vendor/jquery/jquery.min.js"></script>
            <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

            <!-- Core plugin JavaScript-->
            <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

            <!-- Custom scripts for all pages-->
            <script src="js/sb-admin-2.min.js"></script>







</body>

</html>