<?php
include 'koneksi.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kode'])) {
    $kode = mysqli_real_escape_string($conn, $_POST['kode']);

    $query = "SELECT * FROM booking WHERE no_transaksi = '$kode'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);

        // Update status
        mysqli_query($conn, "UPDATE booking SET status = 'berhasil' WHERE no_transaksi = '$kode'");

        echo json_encode([
            'status' => 'success',
            'data' => [
                'kode_booking' => $data['no_transaksi'],
                'nama_pemesan' => $data['username'],
                'nama_lapangan' => $data['no_lapangan'],
                'tanggal' => $data['tanggal_transaksi'],
                'total_harga' => $data['total_harga']
            ]
        ]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Kode booking tidak ditemukan!']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Permintaan tidak valid!']);
}
?>
