<?php
include 'koneksi.php';

$nama = $_POST['nama_lapangan'];
$fasilitas = $_POST['fasilitas'];

// Handle file upload
$namaFile = $_FILES['gambar']['name'];
$tmpName = $_FILES['gambar']['tmp_name'];
$folder = "uploads/";

// Pastikan folder "uploads" sudah ada atau buat pakai mkdir()
if (!file_exists($folder)) {
    mkdir($folder, 0777, true);
}

$pathFile = $folder . $namaFile;

if (move_uploaded_file($tmpName, $pathFile)) {
    $sql = "INSERT INTO lapangan (namalapangan, fasilitas, gambar)
            VALUES ('$nama', '$fasilitas', '$namaFile')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Lapangan berhasil ditambahkan'); window.location.href='manajemenlapangan.php';</script>";
    } else {
        echo "Gagal menambahkan ke database: " . mysqli_error($conn);
    }
} else {
    echo "Upload gambar gagal.";
}
?>
