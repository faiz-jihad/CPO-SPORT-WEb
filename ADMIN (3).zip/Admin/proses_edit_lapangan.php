<?php
include 'koneksi.php';

if (isset($_POST['update'])) {
    $no_lapangan = $_POST['no_lapangan']; // id lapangan
    $namalapangan = $_POST['namalapangan'];
    $fasilitas = $_POST['fasilitas'];
    $gambar_lama = $_POST['gambar_lama']; // Gambar lama yang ada
    $gambar_baru = $_FILES['gambar']['name']; // Gambar baru jika ada

    // Jika gambar baru diupload, lakukan proses upload
    if (!empty($gambar_baru)) {
        // Tentukan lokasi file untuk gambar baru
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($gambar_baru);

        // Upload gambar baru
        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
            // Jika gambar berhasil diupload, update dengan gambar baru
            $update = mysqli_query($conn, "UPDATE lapangan SET 
                namalapangan='$namalapangan',
                fasilitas='$fasilitas',
                gambar='$gambar_baru'
                WHERE no_lapangan='$no_lapangan'");

            // Hapus gambar lama jika ada gambar baru yang diupload
            if ($update && !empty($gambar_lama)) {
                unlink($target_dir . $gambar_lama); // Menghapus gambar lama dari folder
            }
        }
    } else {
        // Jika gambar tidak diubah, update data tanpa mengganti gambar
        $update = mysqli_query($conn, "UPDATE lapangan SET 
            namalapangan='$namalapangan',
            fasilitas='$fasilitas'
            WHERE no_lapangan='$no_lapangan'");
    }

    // Cek apakah query berhasil
    if ($update) {
        header("Location: lapangan.php?notif=edit-berhasil");
    } else {
        header("Location: lapangan.php?notif=edit-gagal");
    }
}
