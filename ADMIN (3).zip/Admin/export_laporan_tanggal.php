<?php
include 'koneksi.php';

header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=transaksi_hari_ini.xls");

date_default_timezone_set('Asia/Jakarta');
$tanggalHariIni = date('Y-m-d');

$query = "SELECT booking.no_transaksi, pelanggan.username, lapangan.no_lapangan, booking.tanggal_transaksi, booking.total_harga, booking.status, booking.jam_mulai,booking.jam_selesai
FROM booking
JOIN pelanggan ON booking.id_pelanggan = pelanggan.id_pelanggan
JOIN lapangan ON booking.no_lapangan = lapangan.no_lapangan
WHERE DATE(booking.tanggal_transaksi) = '$tanggalHariIni'
ORDER BY booking.tanggal_transaksi DESC";

$result = mysqli_query($conn, $query);
?>

<h3>Data Transaksi Hari Ini - <?= date('d M Y') ?></h3>
<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>No Transaksi</th>
            <th>Username</th>
            <th>No Lapangan</th>
            <th>Jam Mulai</th>
            <th>Jam Selesai</th>
            <th>Tanggal</th>
            <th>Total Harga</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['no_transaksi'] ?></td>
                <td><?= $row['username'] ?></td>
                <td><?= $row['no_lapangan'] ?></td>
                <td><?= date('H:i', strtotime($row['jam_mulai'])) ?></td>
                <td><?= date('H:i', strtotime($row['jam_selesai'])) ?></td>
                <td><?= date('d-m-Y', strtotime($row['tanggal_transaksi'])) ?></td>
                <td>Rp <?= number_format($row['total_harga'], 0, ',', '.') ?></td>
                <td><?= $row['status'] ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>
