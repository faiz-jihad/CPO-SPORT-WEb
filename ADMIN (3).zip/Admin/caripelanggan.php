<?php
include 'koneksi.php';

// Ambil parameter pencarian dari URL jika ada
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Query SQL untuk mengambil data berdasarkan pencarian
$query = "SELECT * FROM pelanggan";

// Jika ada parameter pencarian, tambahkan klausa WHERE untuk mencari nama pelanggan
if (!empty($search)) {
    $query .= " WHERE username LIKE '%$search%'";
}

$data = mysqli_query($conn, $query);
$i = 1;
while ($d = mysqli_fetch_array($data)) {
?>
        <tr>
            <td><?php echo $i++; ?></td>
            <th><?php echo $d['id_pelanggan']; ?></th>
            <th><?php echo $d['Nama']; ?></th>
            <th><?php echo $d['Username']; ?></th>
            <th><?php echo $d['Phone']; ?></th>
            <th><?php echo $d['Password']; ?></th>
            <th>
                <a href="#" class="btn btn-success">Edit</a>
                <a href="#" class="btn btn-danger">Hapus</a>
            </th>
        </tr>
<?php
}
?>
