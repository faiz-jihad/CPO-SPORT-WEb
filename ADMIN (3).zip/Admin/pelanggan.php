<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: loginadmin.php");
    exit();
}


// Ambil idAdmin dari session (pastikan idAdmin disimpan saat login)
$idAdmin = $_SESSION['idAdmin'] ?? null;

if ($idAdmin) {
    $query = "SELECT namaAdmin , jabatan FROM admincpo WHERE idAdmin = '$idAdmin'";
    $result = mysqli_query($conn, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        $namaAdmin = $row['namaAdmin'];
        $jabatan = $row['jabatan'];
    } else {
        exit();
    }
} else {
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>CPO SPORT ADMIN</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">


</head>

<!-- Modal Notif -->
<!-- Notifikasi Modal -->
<div class="modal fade" id="notifModal" tabindex="-1" aria-labelledby="notifModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="notifModalLabel">Notifikasi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="notifMessage">
                <!-- Pesan akan muncul di sini -->
            </div>
            <div class="modal-footer">
                <a href="pelanggan.php" class="btn btn-secondary">Tutup</a>
            </div>
        </div>
    </div>
</div>


<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboardadmin.php">
                <div class="sidebar-brand-icon rotate-n-0">
                    <i class="bi bi-briefcase-fill"></i>
                </div>
                <div class="sidebar-brand-text mx-3">CPO | ADMIN <sup>2</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="dashboardadmin.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Fitur
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="bi bi-people-fill"></i>
                    <span>Data Pelanggan</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="pelanggan.php">Akun Pelanggan</a>
                        <a class="collapse-item" href="transaksipelanggan.php">Transaksi Pelanggan</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link" href="lapangan.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Lapangan</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="komentar.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Komentar</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="daftaradmin.php">
                    <i class="bi bi-person-badge-fill"></i>
                    <span>Kelola Admin</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseketentuan"
                    aria-expanded="true" aria-controls="collapseketentuan">
                    <i class="bi bi-body-text"></i>
                    <span>Data Ketentuan</span>
                </a>
                <div id="collapseketentuan" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="EditTentangKita.php">Tentang Kita</a>
                        <a class="collapse-item" href="pelayanan.php">Pelayanan</a>
                        <a class="collapse-item" href="ketentuanberlaku.php">Ketentuan Berlaku</a>
                    </div>
                </div>
            </li>


            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" name="search" value="<?php $search = $_GET['search'] ?? '';
                                                                    echo htmlspecialchars($search);
                                                                    ?>" class="form-control bg-light border-0 small" placeholder="Cari Berdasarkan Nama...">

                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>

                            <!-- Dropdown - Search -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form action="caripelanggan.php" method="GET" class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" name="search" class="form-control bg-light border-0 small"
                                            placeholder="Search by name..." aria-label="Search" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="submit">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        </a>
                        <!-- Dropdown - Messages -->
                        <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                            aria-labelledby="searchDropdown">
                            <form class="form-inline mr-auto w-100 navbar-search">
                                <div class="input-group">
                                    <input type="text" class="form-control bg-light border-0 small"
                                        placeholder="Search for..." aria-label="Search"
                                        aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fas fa-search fa-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        </li>



                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <div class="text-right mr-2">
                                    <div class="text-gray-900 big"><?php echo $namaAdmin; ?></div>
                                    <div class="text-gray-600 small"><?php echo $jabatan; ?></div>
                                </div>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logoutadmin.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Data Pelanggan -->
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Data Pelanggan</h1>
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <a href="tambahakun.php" class="btn btn-primary">Tambah Akun</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>ID Pelanggan</th>
                                            <th>Nama</th>
                                            <th>Username</th>
                                            <th>no Handphone</th>
                                            <th>Password</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    include 'koneksi.php';

                                    // Ambil parameter pencarian dari URL jika ada
                                    $search = isset($_GET['search']) ? $_GET['search'] : '';

                                    // Query SQL untuk mengambil data berdasarkan pencarian
                                    $query = "SELECT * FROM pelanggan";
                                    if (!empty($search)) {
                                        $query .= " WHERE username LIKE ?";
                                    }

                                    // Siapkan query dan bind parameter
                                    $stmt = $conn->prepare($query);

                                    if (!empty($search)) {
                                        $searchTerm = "%$search%";
                                        $stmt->bind_param("s", $searchTerm); // "s" untuk string
                                    }

                                    $stmt->execute();
                                    $result = $stmt->get_result();

                                    $i = 1;
                                    while ($d = $result->fetch_assoc()) {
                                    ?>
                                        <tr>
                                            <td><?php echo $i++; ?></td>
                                            <th><?php echo $d['id_pelanggan']; ?></th>
                                            <th><?php echo $d['Nama']; ?></th>
                                            <th><?php echo $d['Username']; ?></th>
                                            <th><?php echo $d['Phone']; ?></th>
                                            <th><?php echo $d['Password']; ?></th>
                                            <th>
                                                <a href="#"
                                                    class="btn btn-success btn-edit"
                                                    data-id="<?php echo $d['id_pelanggan']; ?>"
                                                    data-nama="<?php echo $d['Nama']; ?>"
                                                    data-username="<?php echo $d['Username']; ?>"
                                                    data-phone="<?php echo $d['Phone']; ?>"
                                                    data-password="<?php echo $d['Password']; ?>"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#editModal">
                                                    Edit
                                                </a>

                                                <a href="hapuspelanggan.php?id=<?php echo $d['id_pelanggan']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus akun ini?')">Hapus</a>
                                            </th>
                                        </tr>
                                    <?php } ?>

                                </table>
                            </div>
                        </div>
                    </div>




                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; CPO SPORT ADMIN </span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logoutadmin.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Modal -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const editButtons = document.querySelectorAll('.btn-edit');

            editButtons.forEach(button => {
                button.addEventListener('click', () => {
                    document.getElementById('edit-id').value = button.dataset.id;
                    document.getElementById('edit-nama').value = button.dataset.nama;
                    document.getElementById('edit-username').value = button.dataset.username;
                    document.getElementById('edit-phone').value = button.dataset.phone;
                });
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            // Cek apakah ada parameter 'notif' di URL
            const urlParams = new URLSearchParams(window.location.search);
            const notif = urlParams.get('notif');

            if (notif) {
                let message = '';

                // Tentukan pesan berdasarkan nilai 'notif'
                if (notif === 'tambah-berhasil') {
                    message = 'Akun berhasil ditambahkan!';
                } else if (notif === 'tambah-gagal') {
                    message = 'Akun gagal ditambahkan!';
                } else if (notif === 'hapus-berhasil') {
                    message = 'Akun berhasil dihapus!';
                } else if (notif === 'hapus-gagal') {
                    message = 'Akun gagal dihapus!';
                }

                // Tampilkan modal dengan pesan
                $('#notifMessage').text(message);
                $('#notifModal').modal('show');
            }
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const editButtons = document.querySelectorAll('.btn-edit');

            editButtons.forEach(button => {
                button.addEventListener('click', () => {
                    document.getElementById('edit-id').value = button.dataset.id;
                    document.getElementById('edit-nama').value = button.dataset.nama;
                    document.getElementById('edit-username').value = button.dataset.username;
                    document.getElementById('edit-phone').value = button.dataset.phone;
                });
            });
        });
    </script>

    <!-- Modal Edit Pelanggan -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" action="proses_edit_pelanggan.php" class="modal-content">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title" id="editModalLabel">Edit Data Pelanggan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="edit-id">
                    <div class="mb-3">
                        <label>Nama</label>
                        <input type="text" name="nama" id="edit-nama" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Username</label>
                        <input type="text" name="username" id="edit-username" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>No Handphone</label>
                        <input type="text" name="phone" id="edit-phone" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Password (kosongkan jika tidak ingin mengubah)</label>
                        <input type="password" name="password" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="update" class="btn btn-primary">Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </form>
        </div>
    </div>


</body>

</html>