<?php
include 'koneksi.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $tanggal = $_POST['tanggal_transaksi'];
    $jam_mulai = $_POST['jam_mulai'];
    $durasi_jam = intval($_POST['durasi']);

    // Hitung jam selesai
    $jam_selesai = date("H:i", strtotime("+$durasi_jam hours", strtotime($jam_mulai)));

    // Simpan durasi dalam format H:i:s (contoh: "02:00:00")
    $durasi_sql = sprintf("%02d:00:00", $durasi_jam);

    $query = "UPDATE booking SET tanggal_transaksi = ?, jam_mulai = ?, jam_selesai = ?, durasi = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssi", $tanggal, $jam_mulai, $jam_selesai, $durasi_sql, $id);
    $stmt->execute();

    header("Location: transaksipelanggan.php");
    exit();
}
