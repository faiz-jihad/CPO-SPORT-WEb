<?php
include 'koneksi.php';

$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM pelanggan WHERE id_pelanggan = '$id'");
$d = mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Pelanggan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
</head>

<body class="container mt-5">
    <h2>Edit Data Pelanggan</h2>
    <form method="POST" action="">
        <input type="hidden" name="id" value="<?php echo $d['id_pelanggan']; ?>">
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="<?php echo $d['Nama']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control" value="<?php echo $d['Username']; ?>" required>
        </div>
        <div class="mb-3">
            <label>No Handphone</label>
            <input type="text" name="phone" class="form-control" value="<?php echo $d['Phone']; ?>" required>
        </div>
        <!-- Optional: edit password (tidak disarankan tampilkan password asli) -->
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" placeholder="Masukkan password baru jika ingin mengganti">
        </div>
        <button class="btn btn-primary" type="submit" name="update">Simpan Perubahan</button>
        <a href="pelanggan.php" class="btn btn-secondary">Batal</a>
    </form>

    <?php
    if (isset($_POST['update'])) {
        $nama = $_POST['nama'];
        $username = $_POST['username'];
        $phone = $_POST['phone'];
        $password = $_POST['password'];

        // Jika password diisi, update password juga
        if (!empty($password)) {
            $update = mysqli_query($conn, "UPDATE pelanggan SET 
                Nama='$nama', 
                Username='$username', 
                Phone='$phone',
                Password='$password' 
                WHERE id_pelanggan='$id'");
        } else {
            // Update tanpa password
            $update = mysqli_query($conn, "UPDATE pelanggan SET 
                Nama='$nama', 
                Username='$username', 
                Phone='$phone' 
                WHERE id_pelanggan='$id'");
        }

        // Di edit_pelanggan.php (di dalam bagian update)
        if ($update) {
            header("Location: pelanggan.php?notif=edit-berhasil");
        } else {
            header("Location: pelanggan.php?notif=edit-gagal");
        }
    }
    ?>
</body>

</html>