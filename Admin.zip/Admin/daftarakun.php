<?php 
include 'koneksi.php';

// menangkap data dari form
$nama     = $_POST['nama'];
$username = $_POST['username'];
$nohp     = $_POST['nohp'];
$password = $_POST['password'];

// cek apakah ada data yang kosong
if (empty($nama) || empty($username) || empty($nohp) || empty($password)) {
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            swal({
                title: 'Gagal!',
                text: 'Semua wajib diisi!',
                icon: 'error',
                button: 'OK'
            }).then((value) => {
                window.history.back(); // kembali ke form sebelumnya
            });
        });
    </script>";
    exit(); 
}


// buat prepared statement
$stmt = mysqli_prepare($conn, "INSERT INTO pelanggan (Nama, Username, Phone, password) VALUES (?, ?, ?, ?)");

// bind parameter
mysqli_stmt_bind_param($stmt, "ssis", $nama, $username, $nohp, $password);

// eksekusi query
if (mysqli_stmt_execute($stmt)) {
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            swal({
                title: 'Berhasil!',
                text: 'Berhasil mendaftarkan akun!',
                icon: 'success',
                button: 'OK'
            }).then((value) => {
                window.location.href = 'pelanggan.php';
            });
        });
    </script>";
} else {
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            swal({
                title: 'Gagal!',
                text: 'Terjadi kesalahan saat menyimpan data.',
                icon: 'error',
                button: 'OK'
            }).then((value) => {
                window.history.back();
            });
        });
    </script>";
}

// tutup koneksi
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
