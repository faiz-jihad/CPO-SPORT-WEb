<?php
include 'koneksi.php';

// Ambil parameter pencarian dari URL jika ada
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Query SQL untuk mengambil data berdasarkan pencarian
$query = "SELECT * FROM booking";

// Jika ada parameter pencarian, tambahkan klausa WHERE untuk mencari nama pelanggan
if (!empty($search)) {
    $query .= " WHERE username LIKE '%$search%'";
}

$data = mysqli_query($conn, $query);
if ($result->num_rows == 0) {
    echo "<div class='alert alert-warning text-center'>Data tidak ditemukan.</div>";
$i = 1;
while ($d = mysqli_fetch_array($data)) {
?>
    <tr>
        <td><?php echo $i++; ?></td>
        <td><?php echo $d['no_transaksi']; ?></td>
        <td><?php echo $d['id_pelanggan']; ?></td>
        <td><?php echo $d['username']; ?></td>
        <td><?php echo $d['no_lapangan']; ?></td>
        <td><?php echo $d['tanggal_transaksi']; ?></td>
        <td><?php echo date("s", strtotime($d['durasi'])); ?></td>
        <td><?php echo date("H:i", strtotime($d['jam_mulai'])); ?></td>
        <td><?php echo date("H:i", strtotime($d['jam_selesai'])); ?></td>
        <td>
            <a href="#" class="btn btn-success">Sukses</a>
            <a href="#" class="btn btn-warning">Edit</a>
            <a href="#" class="btn btn-danger">Batalkan</a>
        </td>
    </tr>
<?php
}};
?>
