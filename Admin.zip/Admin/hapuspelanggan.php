<?php
include 'koneksi.php';

$id = $_GET['id'];

if ($id) {
    $hapus = mysqli_query($conn, "DELETE FROM pelanggan WHERE id_pelanggan = '$id'");

    // Di hapus_pelanggan.php
    if ($hapus) {
        header("Location: pelanggan.php?notif=hapus-berhasil");
    } else {
        header("Location: pelanggan.php?notif=hapus-gagal");
    }
} else {
    echo "<script>alert('ID tidak ditemukan'); window.location='pelanggan.php';</script>";
}
