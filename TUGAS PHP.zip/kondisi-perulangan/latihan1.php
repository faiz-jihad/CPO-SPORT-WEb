<?php
include "header.php";
?>

<h3>Percabangan if</h3>
<?php
$nama = "Faiz Jihad A";
$usia = 18;

if ($usia <= 17) {
  $kategori = "Anak-anak";
} else if ($usia <= 30) {
  $kategori = "Dewasa";
} else {
  $kategori = "Tua";
}

echo "Nama : " . $nama . "<br>";
echo "Usia : " . $usia . "<br>";
echo "Kategori : " . $kategori . "<br>";
?>
<table class="table table-bordered">
  <tr>
    <th class="text-center">NAMA</th>
    <th class="text-center">USIA</th>
    <th class="text-center">KATEGORI</th>
  </tr>
  <tr>
    <td><?= $nama ?></td>
    <td><?= $usia ?></td>
    <td><?= $kategori ?></td>
  </tr>
</table>

<br>

<h3>Percabangan switch</h3>
<?php
$nama = "Faiz Jihad A-";
$menu = 1;

switch ($menu) {
  default:
    $makanan = "Ayam Goreng";
    break;
  case 1:
    $makanan = "Ayam Bakar";
    break;
  case 2:
    $makanan = "Ikan Gurame";
    break;
}
echo "Nama : " . $nama . "<br>";
echo "Menu : " . $menu . "<br>";
echo "Makanan : " . $makanan . "<br>";
?>
<table class="table table-bordered">
  <tr>
    <th class="text-center">NAMA</th>
    <th class="text-center">MENU</th>
    <th class="text-center">MAKANAN</th>
  </tr>
  <tr>
    <td><?= $nama ?></td>
    <td><?= $menu ?></td>
    <td><?= $makanan ?></td>
  </tr>
</table>

<br>

<h3>perulangan for</h3>

<table class="table table-bordered">
  <tr>
    <th class="text-center">NO.</th>
    <th class="text-center">NAMA</th>
  </tr>
  <?php
    for ($nomor = 1; $nomor <= 10; $nomor++) {
  ?>
    <tr>
      <td><?= $nomor ?></td>
      <td><?php echo "Nama " . $nomor; ?></td>
    </tr>
  <?php
  }
  ?>
</table>

<br>

<h3>perulangan while</h3>

<table class="table table-bordered">
  <tr>
    <th class="text-center">NO.</th>
    <th class="text-center">NAMA</th>
  </tr>
  <?php
    $nomor = 1;
    while ($nomor <= 10) {
  ?>
    <tr>
      <td><?= $nomor ?></td>
      <td><?php echo "Nama " . $nomor; ?></td>
    </tr>
  <?php
  $nomor++;
  }
  ?>
</table>

<?php
include "footer.php";
?>